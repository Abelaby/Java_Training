package com.kral.studentmanagement.student;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.bind.annotation.*;

//import downloads.studentmarks.studentmarks\src\main\java\com\kral\studentmanagement\studentmarks\StudentMarksRepository.java
import java.util.List;
//import java.util.Map;

@RestController
@RequestMapping("/api/students")
public class StudentController {

    @Autowired
    private StudentRepository studentRepository;

//    @Autowired
//    private StudentMarksRepository studentMarksRepository;

    @GetMapping("/{id}")
    public Student getStudent(@PathVariable Long id){
        return studentRepository.findById(id).orElse(null);
    }

    @GetMapping(params = "lname")
    public List<Student> getStudentsByLname(@RequestParam String lname) {
        return studentRepository.findByLname(lname);
    }

    @PostMapping
    public Student createStudent(@RequestBody Student student) {
        return studentRepository.save(student);
    }


}
