package com.kral.studentmanagement.student;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.Id;

@Entity

public class Student {

    @Id
    private int id;

    @Column(nullable = false)
    private String fname;

    @Column(nullable = false)
    private String lname;
}
