package com.kral.studentmanagement.student;

public class StudentService {
}
