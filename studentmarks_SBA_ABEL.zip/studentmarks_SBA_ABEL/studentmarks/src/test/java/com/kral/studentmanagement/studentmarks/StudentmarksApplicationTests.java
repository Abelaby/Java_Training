package com.kral.studentmanagement.studentmarks;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class StudentmarksApplicationTests {

	@Test
	void contextLoads() {
	}

}
