package com.kral.studentmanagement.studentmarks;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class StudentmarksApplication {

	public static void main(String[] args) {
		SpringApplication.run(StudentmarksApplication.class, args);
	}

}
