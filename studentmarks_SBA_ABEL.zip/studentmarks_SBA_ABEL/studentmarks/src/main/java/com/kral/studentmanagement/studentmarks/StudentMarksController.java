import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/student-marks")
public class StudentMarksController {

    @Autowired
    private StudentMarksRepository studentMarksRepository;

    @GetMapping("/{id}")
    public StudentMarks getStudentMarksById(@PathVariable Long id) {
        return studentMarksRepository.findById(id).orElse(null);
    }

    @PostMapping
    public StudentMarks createStudentMarks(@RequestBody StudentMarks studentMarks) {
        return studentMarksRepository.save(studentMarks);
    }


}
