import javax.persistence.*;

@Entity
@Table(name = "student_marks")
public class StudentMarks {
    @Id

    private Long id;

    @Column(nullable = false)
    private Long studentId;

    @Column(nullable = false)
    private int math;

    @Column(nullable = false)
    private int physics;

    @Column(nullable = false)
    private int chemistry;


}
